<?php
	//Ket noi MySQL
	$link=mysqli_connect('localhost','root','','shop') or die('Lỗi kết nối');
	//Đồng bộ Collation
	mysqli_query($link,'set names utf8');
?>