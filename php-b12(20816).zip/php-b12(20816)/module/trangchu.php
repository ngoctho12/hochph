        	<h4 class="heading colr">Sản phẩm nổi bật</h4>
            <div id="prod_scroller">
            <a href="javascript:void(null)" class="prev">&nbsp;</a>
       	  <div class="anyClass scrol">
                <ul>
                	<?php
						echo $sql='select `idSP`,`Gia`,`TenSP`,`UrlHinh` from `nn_sanpham` where `AnHien`=1
						 order by `SoLanXem` DESC limit 0,10';
						$rs=mysqli_query($link,$sql);
						while($r=mysqli_fetch_assoc($rs)){
					?>
                        <li>
                            <a href="?mod=chitiet&id=<?php echo $r['idSP'] ?>"><img src="images/sanpham/<?php echo $r['UrlHinh'] ?>" alt="" /></a>
                            <h6 class="colr"><?php echo $r['TenSP'] ?></h6>
                            <p class="price bold"><?php echo number_format($r['Gia'],0)?>VND</p>
                            <a href="cart.html" class="adcart">Add to Cart</a>
                        </li>
                    <?php
						}
					?>
                </ul>
			</div>
            <a href="javascript:void(null)" class="next">&nbsp;</a>
        </div>
            <div class="clear"></div>
            <div class="listing">
            	<h4 class="heading colr">Sản Phẩm mới</h4>
                <ul>
                	<?php
					
						$sql='select `idSP`,`Gia`,`TenSP`,`UrlHinh` from `nn_sanpham` where `AnHien`=1
						 order by `idSP` DESC limit 0,20';
						 $i=1;
						$rs=mysqli_query($link,$sql);
						while($r=mysqli_fetch_assoc($rs)){
					
					?>
                	<li <?php if($i%4==0) echo 'class="last"';$i++ ?>>
                    	<a href="?mod=chitiet&id=<?php echo $r['idSP'] ?>" class="thumb"><img src="images/sanpham/<?php echo $r['UrlHinh'] ?>" alt="" /></a>
                        <h6 class="colr"><?php echo $r['TenSP'] ?></h6>
                        <div class="stars">
                        	<a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_grey.gif" alt="" /></a>
                            <a href="#">(3) Reviews</a>
                        </div>
                        <div class="addwish">
                        	<a href="#">Add to Wishlist</a>
                            <a href="#">Add to Compare</a>
                        </div>
                        <div class="cart_price">
                        	<a href="cart.html" class="adcart">Thêm Giỏ Hàng</a>
                            <p class="price"><?php echo number_format($r['Gia']/1000000,2) ?> Tr</p>
                        </div>
                    </li>
                    <?php
						}
					?>
                </ul>
            </div>