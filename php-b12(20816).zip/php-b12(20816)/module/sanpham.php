        	<h4 class="heading colr">Featured Products</h4>
            <div class="small_banner">
            	<a href="#"><img src="images/small_banner.gif" alt="" /></a>
            </div>
            <?php
				$idLoai=$_GET['loai'];
				if($idLoai=='')$idLoai=1;
				
				$page=$_GET['trang'];
				if($page=='')$page=1;
				
				$sort=$_GET['thutu'];
				if($sort=='')$sort=1;
				
				$view=$_GET['hienthi'];
				if($view=='')$view=1;
				
				$sql="select count(*) from `nn_sanpham` where `AnHien`=1 and `idLoai`=$idLoai";
				$rs=mysqli_query($link,$sql);
				$r=mysqli_fetch_row($rs);
				$nop=ceil($r[0]/20);
			?>
            <div class="sorting">
            	<p class="left colr"><?php echo $r[0] ?> Sản phẩm - <?php echo $nop ?> Trang</p>
                <ul class="right">                	
                    <li class="text">Page
                    <a title="Trang đầu" href="?mod=sanpham&loai=<?php echo $idLoai ?>&trang=1" class="colr">&lt;&lt;</a>
                    <a title="Trang trước" href="?mod=sanpham&loai=<?php echo $idLoai ?>&trang=<?php echo $page-1?>" class="colr">&lt;</a>
                   	<?php
						//Tinh so trang
						
						
						for($i=1;$i<=$nop;$i++)
						if($i >=$page-5 && $i<=$page+5)
						{
					?>
                        	<a <?php if($i==$page) echo 'class="current"'; ?> href="?mod=sanpham&loai=<?php echo $idLoai ?>&trang=<?php echo $i?>&thutu=<?php echo $sort ?>&hienthi=<?php echo $view ?>" class="colr"><?php echo $i?></a> 
                    <?php
						}
					?> 
                    <a title="Trang sau" href="?mod=sanpham&loai=<?php echo $idLoai ?>&trang=<?php echo $page+1?>" class="colr">&gt;</a>
                    <a title="Trang cuối" href="?mod=sanpham&loai=<?php echo $idLoai ?>&trang=<?php echo $nop?>" class="colr">&gt;&gt;</a>
                   
                    </li>
                </ul>
                <div class="clear"></div>
                <p class="left">View as: <a href="?mod=sanpham&loai=<?php echo $idLoai ?>&trang=<?php echo $page ?>&thutu=<?php echo $sort ?>&hienthi=1" class="bold">Grid</a>&nbsp;<a href="?mod=sanpham&loai=<?php echo $idLoai ?>&trang=<?php echo $page ?>&thutu=<?php echo $sort ?>&hienthi=2" class="colr">List</a></p>
                <ul class="right">
                	<li class="text">
                    	Sort by Position
                    	<a <?php if($sort>2) echo 'class="current"' ?> href="?mod=sanpham&loai=<?php echo $idLoai ?>&trang=<?php echo $page ?>&hienthi=<?php echo $view ?>&thutu=<?php if($sort==3) echo 4;else echo 3 ?>" class="colr">Name <?php if($sort==3)echo '<img src="images/asc.png">' ;if($sort==4) echo '<img src="images/desc.png">'?></a> | 
                        <a <?php if($sort<3) echo 'class="current"' ?> href="?mod=sanpham&loai=<?php echo $idLoai ?>&trang=<?php echo $page ?>&hienthi=<?php echo $view ?>&thutu=<?php if($sort==1) echo 2;else echo 1 ?>" class="colr">Price <?php if($sort==1)echo '<img src="images/asc.png">' ;if($sort==2) echo '<img src="images/desc.png">'?></a> 
                    </li>
                </ul>
          	</div>
            
            <?php
			
				$pos=($page-1)*20;
																		
				$order='`Gia` ASC';
				if($sort==2)
				$order='`Gia` DESC';
				if($sort==3)
				$order='`TenSP` ASC';
				if($sort==4)
				$order='`TenSP` DESC';
				
				echo $sql="select `idSP`,`Gia`,`TenSP`,`UrlHinh`,`MoTa` from `nn_sanpham` 
				where `AnHien`=1 and `idLoai`=$idLoai order by $order limit $pos,20";
				
				$rs=mysqli_query($link,$sql);
			
								
				if($view==1)
				{
			?>
            <div class="listing">
            	<h4 class="heading colr">New Products for March 2010</h4>
                <ul>
                <?php				
						
						$i=1;
						while($r=mysqli_fetch_assoc($rs)){
					
					?>
                	<li <?php if($i%4==0) echo 'class="last"';$i++ ?>>
                    	<a href="?mod=chitiet&id=<?php echo $r['idSP']?>" class="thumb"><img src="images/sanpham/<?php echo $r['UrlHinh'] ?>" alt="" /></a>
                        <h6 class="colr"><?php echo $r['TenSP'] ?></h6>
                        <div class="stars">
                        	<a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_grey.gif" alt="" /></a>
                            <a href="#">(3) Reviews</a>
                        </div>
                        <div class="addwish">
                        	<a href="#">Add to Wishlist</a>
                            <a href="#">Add to Compare</a>
                        </div>
                        <div class="cart_price">
                        	<a href="cart.html" class="adcart">Thêm Giỏ Hàng</a>
                            <p class="price"><?php echo number_format($r['Gia']/1000000,2) ?> Tr</p>
                        </div>
                    </li>
                    <?php
						}
					?>
                </ul>
            </div>
            <?php
				}
				else
				{
					while($r=mysqli_fetch_assoc($rs))
					{
			?>
            			<h6 class="colr"><?php echo $r['TenSP'] ?></h6>
                        <a href="?mod=chitiet&id=<?php echo $r['idSP']?>" class="thumb"><img src="images/sanpham/<?php echo $r['UrlHinh'] ?>" alt="" /></a>
                        <div>
                        	<?php echo $r['MoTa']?>
                        </div>
            <?php
					}
				}
			?>