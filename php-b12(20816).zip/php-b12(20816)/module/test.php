testing
<?php
	echo $_SESSION['id'];
?>