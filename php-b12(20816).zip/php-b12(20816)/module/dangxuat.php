<?php
	//Huy session
	unset($_SESSION['id']);
	unset($_SESSION['name']);
	//Chuyen toi trang dang nhap
	header('location:?mod=dangnhap');
?>