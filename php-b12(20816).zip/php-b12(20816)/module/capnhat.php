                <?php
					print_r($_POST);
					
					if(isset($_POST['name']))
					{
					
						$name=$_POST['name'];
						$email=$_POST['email'];
						$pass=$_POST['pass'];
						$repass=$_POST['repass'];
						$phone=$_POST['phone'];
						
						if($email=='')
						{
							$msg='Email không được để trống';
						}
						elseif(strlen($pass)<6)
						{
							$msg='Mật khẩu tối thiểu 6 ký tự';
						}
						elseif($repass!=$pass)
						{
							$msg='Mật khẩu nhập lại không đúng';
						}
						else// Hợp lệ => insert vào DB
						{
							$sql="insert into `nn_nguoidung` values(NULL,sha1('$pass'),'$email','$name','$phone','','','',now(),'','','','')";
							$rs=mysqli_query($link,$sql);
							
							if($rs) $msg='Đăng ký thành công <script>
											setTimeout("window.location=\'?mod=dangnhap&email='.$email.'\'",3000);	
										</script>';
							else $msg='Đăng ký không thành công. Email này đã được sử dụng';
							
						}
						
					}
					
				?>
                <h2 class="heading colr">Sign up</h2>
                <div class="login">
                <form action="" method="post" onsubmit="return checkData()"> 
                	<div class="registrd">
                    	<h3>Please Sign up</h3>
                        <p align="center" class="error"><?php echo $msg?></p>
                      <ul class="forms">
                          <li class="txt">Name<span class="req">*</span></li>
                          <li class="inputfield">
                            <input type="text" name="name" class="bar" id="name" />
                          </li>
                        </ul>
                        <ul class="forms">
                          <li class="txt">Email <span class="req">*</span></li>
                          <li class="inputfield">
                            <input type="text" name="email" class="bar" id="email" />
                          </li>
                        </ul>
                        <ul class="forms">
                          <li class="txt">Password <span class="req">*</span></li>
                          <li class="inputfield">
                            <input type="password" name="pass" class="bar" id="pass" />
                          </li>
                      </ul>
                      <ul class="forms">
                          <li class="txt">Retype Password <span class="req">*</span></li>
                          <li class="inputfield">
                            <input type="password" name="repass" class="bar" id="repass" />
                          </li>
                        </ul>
                        <ul class="forms">
                          <li class="txt">Phone<span class="req">*</span></li>
                          <li class="inputfield">
                            <input type="text" name="phone" class="bar" id="phone" />
                          </li>
                        </ul>
                        <ul class="forms">
                       	  <li class="txt">&nbsp;</li>
                            <li><input type="submit" value=" OK "><!--<a href="#" class="simplebtn"><span>Login</span></a>--> <a href="#" class="forgot">Forgot Your Password?</a></li>
                        </ul>
                    </div>
                  </form>
                </div>
                <div class="clear"></div>
                <script>
					function checkData(){
						var a=document.getElementById('name');
						if(a.value=='')
						{
							alert('Họ tên không được để trống');
							a.focus();
							return false;
						}
						
						var emailPat=/^[a-z0-9_.-]{2,}@[a-z0-9.]+[a-z]{2,}$/i;
						var a=document.getElementById('email');
						if(emailPat.test(a.value)==false)
						{
							alert('Email không hợp lệ');
							a.focus();
							return false;
						}
						
						var a=document.getElementById('pass');
						if(a.value.length<6)
						{
							alert('Mật khẩu tối thiểu 6 ký tự');
							a.focus();
							return false;
						}
						
						var b=document.getElementById('repass');
						if(a.value!=b.value)
						{
							alert('Mật khẩu nhâp lại không đúng');
							b.select();
							return false;
						}
						//Tat ca du lieu hop le
						return true;
					}
				</script>