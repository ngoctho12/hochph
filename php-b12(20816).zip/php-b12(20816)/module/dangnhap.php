                <h2 class="heading colr">Login</h2>
                <div class="login">
                <form action="?mod=dangnhap_xuly" method="post"> 
                	<div class="registrd">
                    	<h3>Please Sign In</h3>
                        <p>If you have an account with us, please log in.</p>
                        <ul class="forms">
                        	<li class="txt">Email Address <span class="req">*</span></li>
                            <li class="inputfield"><input value="<?php if(isset($_GET['email'])) echo $_GET['email'] ?>" type="text" name="email" class="bar" /></li>
                        </ul>
                        <ul class="forms">
                        	<li class="txt">Password <span class="req">*</span></li>
                            <li class="inputfield"><input type="password" name="pass" class="bar" /></li>
                        </ul>
                        <ul class="forms">
                        	<li class="txt">&nbsp;</li>
                            <li><input type="submit" value="Login"><!--<a href="#" class="simplebtn"><span>Login</span></a>--> <a href="#" class="forgot">Forgot Your Password?</a></li>
                        </ul>
                    </div>
                  </form>
                    <div class="newcus">
                    	<h3>Please Sign In</h3>
                        <p>
                        	By creating an account with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.
                        </p>
                        <a href="?mod=dangky" class="simplebtn"><span>Register</span></a>
                    </div>
                </div>
                <div class="clear"></div>