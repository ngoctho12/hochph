            <?php
				$id=$_GET['id'];
				
				//Tang so luot xem
				$sql='UPDATE `nn_sanpham` SET `SoLanXem` = `SoLanXem` +1 WHERE `idSP` ='.$id;
				mysqli_query($link,$sql);
				
				//Lay thong tin san pham
				echo $sql='select * from `nn_sanpham` where `idSP`='.$id;
				$rs=mysqli_query($link,$sql);
				$r=mysqli_fetch_assoc($rs);
				
				
			?>
        	<h4 class="heading colr"><?php echo $r['TenSP']?></h4>
            <div class="prod_detail">
            	<div class="big_thumb">
                	<div id="slider2">
                        <div class="contentdiv">
                        	<img src="images/sanpham/<?php echo $r['UrlHinh']?>" alt="" />
                            <a rel="example_group" href="images/sanpham/<?php echo $r['UrlHinh']?>" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit." class="zoom">&nbsp;</a>
                      </div>
<!--                        <div class="contentdiv">
                            <img src="images/detail_img2.gif" alt="" />
                            <a rel="example_group" href="images/watch.jpg" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit." class="zoom">&nbsp;</a>
                        </div>
                        <div class="contentdiv">
                            <img src="images/detail_img3.gif" alt="" />
                            <a rel="example_group" href="images/watch.jpg" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit." class="zoom">&nbsp;</a>
                        </div>
                        <div class="contentdiv">
                        	<img src="images/detail_img4.gif" alt="" />
                            <a rel="example_group" href="images/watch.jpg" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit." class="zoom">&nbsp;</a>
                        </div>
                        <div class="contentdiv">
                        	<img src="images/detail_img5.gif" alt="" />
                            <a rel="example_group" href="images/watch.jpg" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit." class="zoom">&nbsp;</a>
                        </div>
                      <div class="contentdiv">
                        	<img src="images/detail_img6.gif" alt="" />
                            <a rel="example_group" href="images/watch.jpg" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit." class="zoom">&nbsp;</a>
                      </div>-->
                    </div>
                    <a href="javascript:void(null)" class="prevsmall"><img src="images/prev.gif" alt="" /></a>
                    <div style="float:left; width:189px !important; overflow:hidden;">
                    <div class="anyClass" id="paginate-slider2">
                        <ul>
                            <li><a href="#" class="toc"><img src="images/sanpham/<?php echo $r['UrlHinh']?>" alt="" /></a></li>
                            <!--<li><a href="#" class="toc"><img src="images/detail_img2_small.gif" alt="" /></a></li>
                            <li><a href="#" class="toc"><img src="images/detail_img3_small.gif" alt="" /></a></li>
                            <li><a href="#" class="toc"><img src="images/detail_img4_small.gif" alt="" /></a></li>
                            <li><a href="#" class="toc"><img src="images/detail_img5_small.gif" alt="" /></a></li>
                            <li><a href="#" class="toc"><img src="images/detail_img6_small.gif" alt="" /></a></li>-->
                        </ul>
                    </div>
                    </div>
                    <a href="javascript:void(null)" class="nextsmall"><img src="images/next.gif" alt="" /></a>
                    <script type="text/javascript" src="js/cont_slidr.js"></script>
                </div>
                <div class="desc">
                	<div class="quickreview">
                            <a href="#" class="bold black left"><u>Be the first to review this product</u></a>
                            <div class="clear"></div>
                            <p class="avail"><span class="bold">
                            		Availability: </span> <?php echo $r['TonKho']?><br>
                                    
                                    <span class="bold">View: </span> <?php echo $r['SoLanXem']?>
                            </p>
                          <h6 class="black">Quick Overview</h6>
                        <p>
                        	 <?php echo $r['MoTa']?>
                        </p>
                    </div>
                    <div class="addtocart">
                    	<h4 class="left price colr bold"> <?php echo number_format($r['Gia'],0) ?> VND</h4>
                            <div class="clear"></div>
                            <ul class="margn addicons">
                                <li>
                                    <a href="#">Add to Wishlist</a>
                                </li>
                                <li>
                                    <a href="#">Add to Compare</a>
                                </li>
                        	</ul>
                            <div class="clear"></div>
                        <ul class="left qt">
                   	    <li class="bold qty">QTY</li>
                            <li><input name="qty" type="text" class="bar" /></li>
                            <li><a href="cart.html" class="simplebtn"><span>Add To Cart</span></a></li>
                        </ul>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="prod_desc">
                	<h4 class="heading colr">Product Description</h4>
                    <p>
                    	<?php echo $r['ChiTiet']?> 
                    </p>
                </div>
            </div>
            <div class="listing">
            	<h4 class="heading colr">New Products for March 2010</h4>
                <ul>
                    <?php
					
						$sql='select `idSP`,`Gia`,`TenSP`,`UrlHinh` from `nn_sanpham` where `AnHien`=1
						AND `idLoai`='.$r['idLoai'].' AND `idSP`!='.$id.' order by `idSP` DESC limit 0,20';
						 $i=1;
						$rs=mysqli_query($link,$sql);
						while($r=mysqli_fetch_assoc($rs)){
					
					?>
                	<li <?php if($i%4==0) echo 'class="last"';$i++ ?>>
                    	<a href="" class="thumb"><img src="images/sanpham/<?php echo $r['UrlHinh'] ?>" alt="" /></a>
                        <h6 class="colr"><?php echo $r['TenSP'] ?></h6>
                        <div class="stars">
                        	<a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_green.gif" alt="" /></a>
                            <a href="#"><img src="images/star_grey.gif" alt="" /></a>
                            <a href="#">(3) Reviews</a>
                        </div>
                        <div class="addwish">
                        	<a href="#">Add to Wishlist</a>
                            <a href="#">Add to Compare</a>
                        </div>
                        <div class="cart_price">
                        	<a href="cart.html" class="adcart">Thêm Giỏ Hàng</a>
                            <p class="price"><?php echo number_format($r['Gia']/1000000,2) ?> Tr</p>
                        </div>
                    </li>
                    <?php
						}
					?>
                    
                </ul>
            </div>
            <div class="tags_big">
            	<h4 class="heading">Product Tags</h4>
                <p>Add Your Tags:</p>
                <span><input name="tags" type="text" class="bar" /></span>
                <div class="clear"></div>
                <span><a href="#" class="simplebtn"><span>Add Tags</span></a></span>
                <p>Use spaces to separate tags. Use single quotes (') for phrases.</p>
            </div>
            <div class="clear"></div>