<?php
	//Lay thong tin nguoi dung submit
	//print_r($_POST);	
	//echo 'email:',$_POST['email'],'<br>Pass:',$_POST['pass'];	
	//echo "email:{$_POST['email']}<br>Pass:{$_POST['pass']}";
	
	$email=$_POST['email'];
	//$secret='ti@teo';
	//$pass=sha1(sha1($_POST['pass']).$secret);
	$pass=sha1($_POST['pass']);
	
	
	//Kiem tra thong tin dang nhap
	echo $sql="SELECT * FROM `nn_nguoidung` WHERE `Email` = '$email' AND `MatKhau` = '$pass'";
	$rs=mysqli_query($link,$sql);
	
	if(mysqli_num_rows($rs)==0)//Sai
	{
		echo 'Email hoặc mật khẩu không đúng !';
		echo '<script>
				setTimeout("window.location=\'?mod=dangnhap&email='.$email.'\'",3000);	
			</script>';
	}
	else //Đúng
	{
		$r=mysqli_fetch_assoc($rs);
		//echo 'Đăng nhập thành công';
		//$logined=1;
		$_SESSION['id']=$r['idNguoiDung'];
		$_SESSION['name']=$r['HoTen'];
		//Chuyen toi trang chu
		header('location:?mod=trangchu');
	}
	
?>
